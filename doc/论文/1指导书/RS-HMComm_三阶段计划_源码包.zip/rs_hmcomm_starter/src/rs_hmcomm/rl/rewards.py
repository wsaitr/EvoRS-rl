from __future__ import annotations
from dataclasses import dataclass
from collections import Counter
from rs_hmcomm.core import MessageBus

@dataclass
class RewardWeights:
    task: float = 1.0
    communication_cost: float = 0.02
    redundancy: float = 0.05

def communication_cost(bus: MessageBus) -> float:
    s = bus.stats()
    return s["messages"] + 0.001*s["text_chars"] + 0.10*s["struct_nodes"] + 0.25*s["latent_handles"]

def redundancy_cost(bus: MessageBus) -> float:
    payloads = [(m.receiver, tuple(sorted(m.node_ids)), m.text.strip().lower()) for m in bus.messages]
    counts = Counter(payloads)
    return float(sum(max(0, n - 1) for n in counts.values()))

def team_reward(task_score: float, bus: MessageBus, weights: RewardWeights | None = None) -> float:
    w = weights or RewardWeights()
    return w.task*task_score - w.communication_cost*communication_cost(bus) - w.redundancy*redundancy_cost(bus)
